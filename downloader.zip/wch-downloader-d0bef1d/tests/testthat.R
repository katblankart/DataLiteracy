library(testthat)
library(downloader)

test_check("downloader")
